# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   VMuus, 02/12/2018, Added code to complete assignment 5
#   VMuus, 02/14/2018, Added functions: LoadFile(), DisplayMenu(), DisplayTasks(), AddTask(), RemoveTask() SaveTasks(lstTable)
#   VMuus, 02/14/2018, Added a Tasks class to manage lstTable functions
#   VMuus, 02/19/2018, Added formatting and more communication to user
#
#  -------------------------------------------------#

# -- Data --#
objFileName = "C:\\_PythonClass\\Todo.txt"
lstTable=[]     # A dictionary that acts as a 'table' of rows


class Tasks(object):
    
    """ This class contains methods for displaying, saving and modifying Tasks list """

    # Define the method to read data from file
    @staticmethod
    def LoadFile():

        """ This function reads data from a file and stores it into a table """

        # Open file for reading
        objFile = open(objFileName, "r")

        # Read each line in the data file and set each comma delimitted values
        # to a dictionary and then those to a list object
        for line in objFile:
            x, y = line.split(',')
            x = x.strip()
            y = y.strip()
            # Add the dictionary rows to a python list table
            lstTable.append({"Task": x, "Priority": y})

        # Close/save file
        objFile.close()

        return lstTable

     
    # Define the method to display current list of tasks
    @staticmethod
    def DisplayTasks():

        """ This function displays the current list of tasks as stored in list table """
        print("\n---------------------\nCurrent to do list: ")
        for row in lstTable:
            print("  * " + row["Task"] + " - " + row["Priority"])
        print("---------------------\n")
              
    # Define the method to save current list of tasks
    @staticmethod
    def SaveTasks(lstTable):

        """ This function saves the current list of tasks as stored in list table into the Todo file """

        # Open the data file with w+ so as to be able to just overwrite new data table
        objFile = open(objFileName, "w+")

        for row in lstTable:
            objFile.write(row["Task"])
            objFile.write(",")
            objFile.write(row["Priority"])
            objFile.write("\n")

        # Close/save file
        objFile.close()
        print("\nTasks saved to file!")

    # Define the method to display menu options to user and returns user selection
    @staticmethod
    def DisplayMenu():

        """ This function displays the menu of options and returns the user selection """

        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        return str(input("Which option would you like to perform? [1 to 4] - "))

    # Define the method to prompt user for new task to add to list
    @staticmethod
    def AddTask():

        """ This function prompts user for new task to be added, then adds it to the list table """

        # Prompt user for task to add
        task = input("What task would you like to add?: ")
        priority = input("What is its priority?:  ")

        # Set the input as dictionary items
        dicRows = {"Task": task, "Priority": priority}
        # Add the dictionary rows to the python list table
        lstTable.append(dicRows)

        # Confirm with user that task was added
        print("\n\"" + task + ", " + priority + " \" added to the list!")

    # Define the method to prompt user for task to be removed from list
    @staticmethod
    def RemoveTask():

        """ This function prompts user for a task to be deleted, then removes it from the list table """

        term = input("What task do you want to delete?: ")
        match = None
        for l in lstTable:
            if l["Task"] == term:
                match = 1
                lstTable.remove(l)
                # Confirm with user that task was removed
                print("\nTask: \"" + l["Task"] + "\" was removed from the list!")
                break
        if match == None:
            print("That task does not exist.")



# Call LoadFile function to populate lstTable with contents of file
lstTable = Tasks.LoadFile()

# Call function to display tasks
Tasks.DisplayTasks()

# Display a menu of choices to the user
while (True):

    # Call function to display Menu options
    strChoice = Tasks.DisplayMenu()

    # Display current list of tasks
    if strChoice.strip() == '1':
        # Call function to display tasks
        Tasks.DisplayTasks()

    # Add a new item to the list/Table
    elif strChoice.strip() == '2':
        # Add task as specified by user
        Tasks.AddTask()

    # Remove an item from the list/Table
    elif strChoice == '3':
        # Remove task as specified by user
        Tasks.RemoveTask()

    # Save current tasks to the ToDo.txt file
    elif strChoice == '4':
        # Call function to display current tasks
        Tasks.DisplayTasks()
        
        # Prompt user to save current tasks to file
        if (str.lower(input("Save these tasks to the file? (y/n)... ")) == "y"):
            Tasks.SaveTasks(lstTable)
            continue
        else:
            print("\nTasks not saved to the file...")
            continue      
        
    elif strChoice == '5':
        # Save the data from the table into the text file when the program exits
        Tasks.SaveTasks(lstTable)
        print("Goodbye!")
        break  # and Exit the program

    else:
        print("\nSorry, invalid menu option selected, please try again...")
