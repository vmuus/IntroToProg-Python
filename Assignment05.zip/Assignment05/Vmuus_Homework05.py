# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   VMuus, 02/12/2018, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
objFileName = "C:\\_PythonClass\\Todo.txt"
objFile=""      # An object that represents a file
dicRows={}      # A row of data separated into elements of a dictionary {Task,Priority}
dicDataRows={}  # A row of data separated into elements of a dictionary {Task,Priority}
lstTable=[]     # A dictionary that acts as a 'table' of rows

# -- Input/Output --#

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

'''
# Per Assignment Item 2.  When the program starts, load each row of data from the ToDo.txt text file into a
#     Python dictionary. (The data will be stored like a row in a table.)
#     Tip: You can use a for loop to read a single line of text from the file and then
#     place the data into a new dictionary object.
# Per Assignment Item 3.  After you get the data in a Python dictionary, Add the new dictionary “row” into a Python list object
#     (now the data will be managed as a table).
'''

# Open file for reading
objFile = open(objFileName, "r")

# Read each line in the data file and set each comma delimitted values
# to a dictionary and then those to a list object
for line in objFile:
    x, y = line.split(',')
    x = x.strip()
    y = y.strip()
    # Set the input as dictionary items
    dicDataRows = {"Task": x, "Priority": y}
    # Add the dictionary rows to a python list table
    lstTable.append(dicDataRows)

# Close/save file
objFile.close()

# Per Assignment Item 4.  Display the contents of the List to the user.
print("Initial to do list: ")
for row in lstTable:
    print("* " + row["Task"] + " - " + row["Priority"])

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line for formatting purposes

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Current to do list: \n")
        for row in lstTable:
            print("* " + row["Task"] + " - " + row["Priority"])
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        task = input("What task would you like to add?: ")
        priority = input("What is its priority?:  ")
        # Set the input as dictionary items
        dicRows = {"Task": task, "Priority": priority}
        # Add the dictionary rows to the python list table
        lstTable.append(dicRows)
        continue

    # Step 5 - Remove an item from the list/Table
    elif (strChoice == '3'):
        term = input("What task do you want to delete?: ")
        match = None
        for l in lstTable:
            if l["Task"] == term:
                match = 1
                lstTable.remove(l)
                break
        if match == None:
            print("That task does not exist.")
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        # Open the data file with w+ so as to be able to just overwrite new data table
        objFile = open(objFileName, "w+")

        for row in lstTable:
            objFile.write(row["Task"])
            objFile.write(",")
            objFile.write(row["Priority"])
            objFile.write("\n")

        # Close/save file
        objFile.close()
        print("Tasks saved to file!")
        continue

    elif (strChoice == '5'):
        # Per Assignment Item 6.  Save the data from the table into the text file when the program exits.

        # Open the data file
        objFile = open(objFileName, "w+")
        # Save the data to a file
        for row in lstTable:
            objFile.write(row["Task"])
            objFile.write(",")
            objFile.write(row["Priority"])
            objFile.write("\n")

        # Close/save file
        objFile.close()
        print("Goodbye!")
        break  # and Exit the program
